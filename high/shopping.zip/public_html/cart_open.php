<html>
  <head>
    <title>カート - 呉服屋こーかとん</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <link rel="stylesheet" href="./css/mainmenu.css" type="text/css">
    <link rel="stylesheet" href="./css/font-awesome/css/font-awesome.min.css" type="text/css">
<style>
  TABLE{font-size: 16pt;
  margin: 10px 0px;}
  .btn{
	background-color: #dcdcdc;
	color: #333;
    border: 1px solid #DDD;
    border: 1px solid #DDD;
    border-radius: 8px;
    -moz-border-radius: 8px;
    -webkit-border-radius: 8px;
    width: 100px;
    padding: 10px 0;
  }
  .btn:hover {
	background-color: #e0ffff;
  }
</style>
</head>
<body>
  <?php
    require_once __DIR__ . '/UserControll.php';
    session_start();
    require_logined_session();
    $mysqli = new mysqli("");
    $mysqli->query('SET NAMES utf8');//文字コード宣言
    if(mysqli_connect_errno()){
      die("MySQL connection error: " . mysqli_connect_error());
    }
    if(!isset($_SESSION["user"])){
	$cart = 0; //カートに入れた商品の数を取得
    }else{
	$sql="select * from user where mail='".
	htmlspecialchars($_SESSION["user"])."'";
	if(!($result = $mysqli->query($sql))){
		die("SQL error: " . $mysqli->error);
	}
	$row = $result->fetch_array(MYSQLI_ASSOC);
	$sql2="select count(*) from basket where user_id='".$row["user_id"]."'";
	if(!($result2 = $mysqli->query($sql2))){
		die("SQL error: " . $mysqli->error);
	}
	$count = $result2->fetch_array(MYSQLI_BOTH);
	$cart = $count[0]; //カートに入れた商品の数を取得
    }
  ?>
    <script>
      /* 読み込み時と画面サイズ変更時に処理をする */
      $(window).on('load resize', function(){
        var windowsizeW = $(window).width();
	if(windowsizeW < 327){
	  $('div#mainmenu').css('height','276px');
	} else if(windowsizeW < 587){
	  $('div#mainmenu').css('height','207px');
	} else if(windowsizeW < 807){
	  $('div#mainmenu').css('height','138px');
	} else {
	  $('div#mainmenu').css('height','69px');
	}
	$('div#sales_history').css('width',windowsizeW-380+'px');
      });
    </script>
    <div id="mainmenu">
      <a href="./index.php"><img id="shoplogo" src="./pic/sozai/logo.png"></a>
      <div id="menu">
      <div id="right_items">
        <form name="rankingform" id="rankingform" method="get" action="#">
          <select id="ranking_select" name="sel2">
	    <option value="./rank.php">いいねランキング</option>
	    <option value="./search_c.php?category_id=1">カテゴリ:ネタ</option>
	    <option value="./search_c.php?category_id=2">カテゴリ:アニメ</option>
	    <option value="./search_c.php?category_id=3">カテゴリ:ゴッド</option>
	    <option value="./search_c.php?category_id=4">カテゴリ:シュール</option>
          </select>
          <input type="button" id="jumpbutton" onClick="top.location.href=sel2.value" value="Jump!!">
        </form>
        <form name="searchform" id="searchform" method="get" action="./search.php">
          <input type="text" name="word" id="keywords" value="" placeholder="検索" style="height:30px;" />
	  <a href="javascript:void(0)" onclick="document.searchform.submit();return false;"><i class="fa fa-search fa-lg"></i></a>
        </form>
      </div>
      <div id="user_items">
        <ul>
	  <li>
	    <a href='UserMyPage.php'><i class='fa fa-user'></i>Myページ</a>
	  </li>
	  <li>
          <?php
            $tokentmp = h(generate_token());
            echo "<a href='UserLogout.php?token=".$tokentmp."'><i class='fa fa-sign-out'></i>ログアウト</a>";
          ?>
	  </li>
	</ul>
      </div>
      <div id="menu_list">
	<ul>
	  <li><a href="./cart_open.php"><i class="fa fa-shopping-cart"></i><br>カート(<?php echo $cart; ?>)</a></li>
	</ul>
      </div>
    </div>
    </div>
    <?php
    /* ページを開いた時の日時を取得 */
    date_default_timezone_set('Asia/Tokyo');
    $date = date("Y年m月d日 H時i分");

		session_start();
		if(!isset($_SESSION["user"])){ //ログインしてないとページみれないよ
			"ログインしてください。";
		}else{

      /*レシートの表示*/
      /*上部分(ロゴ~注文書)*/
      print "<table style='border: 3px solid #000;'>";
      echo "<tr align="."center"."><td colspan=2 valign="."middle".">
      <img src="."./pic/sozai/logo.png alt=[ロゴ]"." width=350px></td></tr>";
      echo "<tr align="."center"."><td colspan=2 valign="."middle".">電話 090-6618-1424</td></tr>
      <tr align="."center"."><td colspan=2 valign="."middle".">東京都八王子市</td></tr>
      <tr align="."center"."><td colspan=2 valign="."middle".">$date</td></tr>
      <tr align="."center"."><td colspan=2 valign="."middle".">&nbsp;</td></tr>
      <tr align="."center"."><td colspan=2 valign="."middle"."><b>注文書</b></td></tr>";

      $sum = 0; //合計用

			$sql="select * from user where mail='". //ユーザの情報をもってくる
			htmlspecialchars($_SESSION["user"])."'";
			if(!($result = $mysqli->query($sql))){
				die("SQL error: " . $mysqli->error);
			}
			$row = $result->fetch_array(MYSQLI_ASSOC);

			$sql2 = "select * from basket where user_id = '" . $row["user_id"] . "'"; //ユーザのカート情報をもってくる
			if(!($result2 = $mysqli->query($sql2))){
				die("SQL error: " . $mysqli->error);
			}
			while ($data = $result2->fetch_array(MYSQLI_ASSOC)) { //カートの中身の数(商品の種類)だけ繰り返す

				$sql3 = "select * from product where product_id = '" . $data["product_id"] . "'";
				if(!($result3 = $mysqli->query($sql3))){
					die("SQL error: " . $mysqli->error);
				}
				$data2 = $result3->fetch_array(MYSQLI_ASSOC); //商品データをもってくる

        /*値段処理*/
        $nedan = $data2["price"] * $data["purchase_number"]; //商品の原価 * 購入数
        if($data2["discount"] != 0) $nedan = $nedan * $data2["discount"]; //割引があれば割り引く

        /* 表示用に変数にいれとく */
        $name = $data2["product_name"]; //商品名
        $kosu = $data["purchase_number"]; //購入数

        /* 中部分(商品名、購入数、小計) */
				print "<tr><td align="."left".">";
        print "$name";//商品名
        if($kosu > 1){ //個数が2個以上の場合は商品名のあとに「 × 個数」を付け加える
          print "&nbsp;×&nbsp;";
          print"$kosu";
        }
        print "</td><td align="."right".">￥$nedan</td></tr>"; //商品の値段*買った個数
        $sum = $sum + $nedan; //合計用
			}

      /* 下部分(合計、ユーザ名) */
      echo "<tr align="."center"."><td colspan=2 valign="."middle".">&nbsp;</td></tr>";
      echo "<tr><td  align="."left"."><b>合計</b></td><td align="."right".">￥$sum</td></tr>";
      print "<tr align="."left"."><td colspan=2 valign="."middle".">USER : ". $_SESSION["user"] . "</td></tr>";
      echo " </table>";
	  if(isset($_POST["button_1"])){
		  $sql4 = "DELETE FROM basket WHERE user_id=".$row["user_id"];
		  if(!($result4 = $mysqli->query($sql4))){
					die("SQL error: " . $mysqli->error);
		  }
		  header("Location: " . $_SERVER['PHP_SELF']);
	  }
      $result->close();
	  $mysqli->close();
	}
	?>

	<form method="POST" action="">
  <input type="button" class="btn" value="TOPへ" onClick="location.href='./index.php'">
<input type="button" class="btn" value="購入手続きへ" onClick="location.href='./order.php'">
<input type="submit" class="btn" name="button_1" value="中身を空にする">
	</form>


  </body>
</html>
