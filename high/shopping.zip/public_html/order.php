<html>
<head>
  <!--<meta http-equiv="refresh" content="3"; url="./index.php">-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
  <link rel="stylesheet" type="text/css" href="./css/mainmenu.css">
  <link rel="stylesheet" type="text/css" href="./css/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="./css/order.css" type="text/css">
</head>
<body>
  <?php
    ini_set('display_errors',1);
    require_once __DIR__ . '/UserControll.php';
    session_start();
    require_logined_session();
    if(!isset($_SESSION["user"])){
      echo "<font color='black' size=10    ><center>ログインしてください。</center><br />\n";
    }else{
      $mysqli = new mysqli("");
      if(mysqli_connect_errno()){
        die("MySQL connection error: " . mysqli_connect_error());
      }
      $mysqli->query('SET NAMES utf8' );
      if(!isset($_SESSION["user"])){
	$cart = 0; //カートに入れた商品の数を取得
      }else{
	$sql="select * from user where mail='".
	htmlspecialchars($_SESSION["user"])."'";
	if(!($result = $mysqli->query($sql))){
		die("SQL error: " . $mysqli->error);
	}
	$row = $result->fetch_array(MYSQLI_ASSOC);
	$sql2="select count(*) from basket where user_id='".$row["user_id"]."'";
	if(!($result2 = $mysqli->query($sql2))){
		die("SQL error: " . $mysqli->error);
	}
	$count = $result2->fetch_array(MYSQLI_BOTH);
	$cart = $count[0]; //カートに入れた商品の数を取得
      }
  }
  ?>

<script>
 /* 読み込み時と画面サイズ変更時に処理をする */
$(window).on('load resize', function(){
        var windowsizeW = $(window).width();
        if(windowsizeW < 327){
            $('div#mainmenu').css('height','276px');
        } else if(windowsizeW < 587){
            $('div#mainmenu').css('height','207px');
        } else if(windowsizeW < 807){
            $('div#mainmenu').css('height','138px');
        } else {
            $('div#mainmenu').css('height','69px');
        }
    });
</script>
<div id="mainmenu">
    <a href="./index.php"><img id="shoplogo" src="./pic/sozai/logo.png"></a>
    <div id="menu">
    <div id="right_items">
    <form name="rankingform" id="rankingform" method="get" action="#">
    <select id="ranking_select" name="sel2">
    <option value="./rank.php">いいねランキング</option>
    <option value="./search_c.php?category_id=1">カテゴリ:ネタ</option>
    <option value="./search_c.php?category_id=2">カテゴリ:アニメ</option>
    <option value="./search_c.php?category_id=3">カテゴリ:ゴッド</option>
    <option value="./search_c.php?category_id=4">カテゴリ:シュール</option>
    </select>
    <input type="button" id="jumpbutton" onClick="top.location.href=sel2.value" value="Jump!!">
    </form>
    <form name="searchform" id="searchform" method="get" action="./search.php">
    <input type="text" name="word" id="keywords" value="" placeholder="検索" style="height:30px;" />
    <a href="javascript:void(0)" onclick="document.searchform.submit();return false;"><i class="fa fa-search fa-lg"></i></a>
    </form>
    </div>
    <div id="user_items">
    <ul>
    <li>
    <a href='UserMyPage.php'><i class='fa fa-user'></i>Myページ</a>
    </li>
    <li>
  <?php
    $tokentmp = h(generate_token());
echo "<a href='UserLogout.php?token=".$tokentmp."'><i class='fa fa-sign-out'></i>ログアウト</a>";
?>
</li>
</ul>
</div>
<div id="menu_list">
	<ul>
    <li><a href="./cart_open.php"><i class="fa fa-shopping-cart"></i><br>カート(<?php echo $cart; ?>)</a></li>
	</ul>
    </div>
    </div>
    </div>
  <?php
    $sql="select * from user where mail='".
    htmlspecialchars($_SESSION["user"])."'";
    if(!($result = $mysqli->query($sql))){
      die("SQL error: " . $mysqli->error);
    }
    $row = $result->fetch_array(MYSQLI_ASSOC);
    $sql6="select count(*) from basket where user_id='".$row["user_id"]."'";
    if(!($result6 = $mysqli->query($sql6))){
      die("SQL error: " . $mysqli->error);
    }
    $count = $result6->fetch_array(MYSQLI_BOTH);
    if($count[0] < 1){
      echo "<font color='black' size=10    ><center>カートが空です。</center><br />\n";
      echo "<font color='black' size=10    ><center>商品をカートに入れてください。</center><br />\n";
    }else if($row["mail"]==htmlspecialchars($_SESSION["user"])){
      echo "<div align=center style="."margin:30px"."><img src="."./pic/sozai/box.png alt="."商品画像"." style = "."width:200px".">
			Thank you.</div>";
			$sql2="select * from basket where user_id='".$row["user_id"]."'";
			if(!($result2 = $mysqli->query($sql2))){
				die("SQL error: " . $mysqli->error);
			}
			while($data = $result2->fetch_array(MYSQLI_ASSOC)){
				$sql1="select * from product where product_id='".$data["product_id"]."'";
				if(!($result1 = $mysqli->query($sql1))){
					die("SQL error: " . $mysqli->error);
				}
				$row1 = $result1->fetch_array(MYSQLI_ASSOC);

				$sql3="INSERT INTO sales_history (user_id, product_id, purchase_number, date, time) VALUES ('".
				$data["user_id"]."','".$data["product_id"]."','".$data["purchase_number"]."','".date("Y-m-d",time())."','"
				.date("H:i:s",time())."')";
				if(!($result3 = $mysqli->query($sql3))){
					die("SQL error: " . $mysqli->error);
				}

				$num = $row1["stock"] - $data["purchase_number"];
				$sql4 = "UPDATE product SET stock = ".$num." where product_id =".$data["product_id"];
				if(!($result4 = $mysqli->query($sql4))){
					die("SQL error: " . $mysqli->error);
				}
				if($count[0] < 0){
					break;
				}else{
					$count[0]--;
				}
			}
			$sql5 = "DELETE from basket where user_id ='". $row["user_id"] . "'";
			if(!($result5 = $mysqli->query($sql5))){
				die("SQL error: " . $mysqli->error);
			}
		}else{
			print "ERROR.<br>One more order!!";
		}
		$mysqli->close();
	?>
	<div id="Words"><input type="button" id="TOPbutton" style="width: 50%; padding: 10px;" value="TOPへもどる" onClick="location.href='./index.php'"></div>
	</body>
</html>
