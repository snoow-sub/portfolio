<html>
  <head>
    <meta http-equiv="Content-Type"
	  content="text/html;
		   charset=utf-8">
  </head>
  <body>
    
    <br>購入画面<br><br>
    内容が正しければ、「ガムテープを取り出す」ボタンを押してください。<br>
    修正したい場合は、「戻る」ボタンを押してください。<br><br>

    <?php
      session_start();
      //DBへ接続
      $mysqli = new mysqli("mysql1.php.starfree.ne.jp", "tibineko923_user", "yuu0923ki", "tibineko923_data");
      
      if(mysqli_connect_errno()) {
      die("MySQL connection error: " . mysqli_connect_errno());
      }
      
      //SQLの実行
      $sql="SELECT * FROM basket ORDER BY basket_id DESC";
      
      if(!($result = $mysqli->query($sql))){
    die("MySQL error:" .$mysqli->error);
    }
    while($row = $result->fetch_array(MYSQLI_ASSOC)){
    //数値添字配列 :MYSQLI_NUM
    //連想配列 :MYSQLI_ASSOC
    //連想配列及び数値添字配列 :MYSQLI_BOTH
    print("〒");
    print $row['d_place_yubin']."<br>";
    print("住所");
    print $row['d_place_address']. "<br>";
    print("お名前");
    print $row['d_name']. "<br>";
    }
    $result->close();
    $mysqli->close();
    ?>

    
    &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
    <input type = "button" value="戻る" onClick="location.href='alumni.hamako-ths.ed.jp/~ei1422/site1.php'"><br>
     &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
    <button type = "button" onclick="">ガムテを取り出す</button>
    
  </body>
</html>
