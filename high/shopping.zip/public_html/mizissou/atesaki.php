<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1/jquery-ui.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1/i18n/jquery.ui.datepicker-ja.min.js"></script>
<script src="https://ajaxzip3.github.io/ajaxzip3.js" charset="UTF-8"></script>
<link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1/themes/ui-lightness/jquery-ui.css" >
<link rel="stylesheet" href="./css/UserCreate.css" type="text/css">
<link rel="stylesheet" href="./css/static.css" type="text/css">
<link rel="stylesheet" href="./css/font-awesome/css/font-awesome.min.css" type="text/css">
<style>
.sbt_1{
	background-color: #dcdcdc;
	color: #333;
    border: 1px solid #DDD;
    border: 1px solid #DDD;
    border-radius: 8px;
    -moz-border-radius: 8px;
    -webkit-border-radius: 8px;
    width: 100px;
    padding: 10px 0;
}
.sbt_1:hover {
	background-color: #e0ffff;
}
</style>
</head>
<body>
<br>宛先入力<br><br><br><br>
<?php
session_start();
//DBへ接続
$mysqli = new mysqli("mysql1.php.starfree.ne.jp", "tibineko923_user", "yuu0923ki", "tibineko923_data");
$mysqli->query('SET NAMES utf8');

if(mysqli_connect_errno()){
	die("MySQL connection error:". mysqli_connect_errno());
}

//SQL文を変数に格納
$sql="SELECT * FROM user WHERE mail='".htmlspecialchars($_SESSION['user'])."'";

if(!($result = $mysqli->query($sql))){
	die("MySQL error:".$mysqli->error);
}
$row = $result->fetch_array(MYSQLI_ASSOC);
$num = $row["place_yubin"];
$ad = $row["place_address"];
$name = $row["user_family"]." ".$row["user_name"];
$result->close();
$mysqli->close();


print '<form action=site1.php method="get">';
print '〒<input type="text" name="place_yubin" class="textbx" value="'.$num.'"maxlength="7" onKeyUp="AjaxZip3.zip2addr(this,\'\',\'place_address\',\'place_address\');" required>(ハイフンなし)<br>';
print '住所<input type="text" name="place_address" class="textbx" value="'.$ad.'" required><br>';
print 'お名前<input type="text" name="d_name" class="textbx" value="'.$name.'"/><br><br>';
print '<input type = "submit" class="sbt_1" value="次へ" onClick="location.href=\'./kounyu.php\'"><br>';
print '</form>';
?>
</body>
</html>
