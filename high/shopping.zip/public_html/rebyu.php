<html>
<body>
<?php
header("Content-type: text/html; charset=utf-8");
ini_set('display_errors',1);
require_once __DIR__ . '/UserControll.php';
session_start();
require_logined_session();
//データベース接続
$server = "";
$userName = "";
$password = "";
$dbName = "";
$mysqli = new mysqli($server, $userName, $password,$dbName);
$mysqli->query('SET NAMES utf8' );
if ($mysqli->connect_error){
    echo $mysqli->connect_error;
    exit();
}

if(!empty($_POST)) {
//名前入力判定
    if (!isset($_POST['rebyutext'])  || $_POST['rebyutext'] === "" ){
        echo "レビューがかきこまれていません";
}else{
        $sql="SELECT user_id from user WHERE mail='". $_SESSION['user'] . "'";
        $user_id_get = $mysqli->query($sql);
        if($user_id_get === false){
          die("SQL error: ".$mysqli->error);
        }
        $row = $user_id_get->fetch_array(MYSQLI_ASSOC);
        $product_id=$_POST['product_id'];
        $user_id=$row['user_id'];
        $date=date("Y-m-d",time());
        $time=date("H:i:s",time());
        $evaluation=$_POST['review_point'];
        $rebyutext=$_POST['rebyutext'];
        $sql="INSERT INTO review ( product_id,user_id,date,time,evaluation,review_text ) VALUES ('$product_id','$user_id','$date','$time','$evaluation','$rebyutext')";

        $result = $mysqli->query($sql);
        if($result === false){
            die("SQL error: ".$mysqli->error);
        } else {
            $_SESSION["message"] = "レビューを追加しました";
            //while ($row = $sql->fetch_array(MYSQLI_ASSOC)) {
            //    $text = htmlspecialchars($row['review_text']);
            //}
            //$_SESSION["review_text"]=$text;
            //echo '<a class="text">'.$text'</a>';

        }
    }
}
$url = "syouhin.php?id=".$product_id;
header('Location: '.$url);
// データベース切断
$mysqli->close();
?>

    </body>
    </html>
