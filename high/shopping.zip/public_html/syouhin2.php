<?php
/* いいねボタン処理 */
if(isset($_POST["button_1"])){
	$kbn = htmlspecialchars($_POST["button_1"], ENT_QUOTES, "UTF-8");
	$s = substr($kbn, 0, 6);
	switch($s){
	case "いい":
		$b += 1;
		$sql = "UPDATE product SET button_1='".$b."' WHERE product_id=".$a;
		if(!($result = $mysqli->query($sql))){
 			print "Error";
			die("SQL error: ".$mysqli->error  );
		}
		//echo '<script type="text/javascript">window.location.reload();</script>';
		header( "Location: ./syouhin2.php?id=".$a );
		break;
	case "爆笑":
		$c += 1;
		$sql = "UPDATE product SET button_2='".$c."' WHERE product_id=".$a;
		if(!($result = $mysqli->query($sql))){
 			print "Error";
			die("SQL error: ".$mysqli->error  );
		}
		//echo '<script type="text/javascript">window.location.reload();</script>';
		header( "Location: ./syouhin2.php?id=".$a );
		break;
	case "ちょ":
		$d += 1;
		$sql = "UPDATE product SET button_3='".$d."' WHERE product_id=".$a;
		if(!($result = $mysqli->query($sql))){
 			print "Error";
			die("SQL error: ".$mysqli->error  );
		}
		//echo '<script type="text/javascript">window.location.reload();</script>';
		header( "Location: ./syouhin2.php?id=".$a );
		break;
	}
}
?>
<!DOCTYPE html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<html>
<head>
  <title>商品詳細 - 呉服屋こーかとん</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="./css/mainmenu.css">
<link rel="stylesheet" type="text/css" href="./css/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="./css/syouhin.css">
</head>
<body>
<?php
ini_set('display_errors',1);
require_once __DIR__ . '/UserControll.php';
session_start();
require_logined_session();

$mysqli = new mysqli("");
$mysqli->query('SET NAMES utf8' );

if(mysqli_connect_errno()){
die("MySQL connection error: " . mysqli_connect_error());
}

if(!isset($_SESSION["user"])){
	$cart = 0; //カートに入れた商品の数を取得
}else{
	$sql="select * from user where mail='".
	htmlspecialchars($_SESSION["user"])."'";
	if(!($result = $mysqli->query($sql))){
		die("SQL error: " . $mysqli->error);
	}
	$row = $result->fetch_array(MYSQLI_ASSOC);
	$sql2="select count(*) from basket where user_id='".$row["user_id"]."'";
	if(!($result2 = $mysqli->query($sql2))){
		die("SQL error: " . $mysqli->error);
	}
	$count = $result2->fetch_array(MYSQLI_BOTH);
	$cart = $count[0]; //カートに入れた商品の数を取得
}
?>
    <script>
      /* 読み込み時と画面サイズ変更時に処理をする */
      $(window).on('load resize', function(){
        var windowsizeW = $(window).width();
	if(windowsizeW < 327){
	  $('div#mainmenu').css('height','276px');
	} else if(windowsizeW < 587){
	  $('div#mainmenu').css('height','207px');
	} else if(windowsizeW < 807){
	  $('div#mainmenu').css('height','138px');
	} else {
	  $('div#mainmenu').css('height','69px');
	}
      });
      $(function() {	
	$('div#review_star > i').on("click",function(){
          var index = $('div#review_star > i').index(this);
          $('input#review_point').val(index+1);
          for(var now=1;now<=5;now++) {
            if(now-1 <= index && $('div#review_star > i:nth-child('+now+')').hasClass('fa-star-o')){
	      $('div#review_star > i:nth-child('+now+')').removeClass('fa-star-o').addClass('fa-star');
            } else if(now-1 > index && $('div#review_star > i:nth-child('+now+')').hasClass('fa-star')){
	      $('div#review_star > i:nth-child('+now+')').removeClass('fa-star').addClass('fa-star-o');
            }
          }
        });
      });				
    </script>
    <div id="mainmenu">
      <a href="./index.php"><img id="shoplogo" src="./pic/sozai/logo.png"></a>
      <div id="menu">
      <div id="right_items">
        <form name="rankingform" id="rankingform" method="get" action="#">
          <select id="ranking_select" name="sel2">
	    <option value="./rank.php">いいねランキング</option>
	    <option value="./search_c.php?category_id=1">カテゴリ:ネタ</option>
	    <option value="./search_c.php?category_id=2">カテゴリ:アニメ</option>
	    <option value="./search_c.php?category_id=3">カテゴリ:ゴッド</option>
	    <option value="./search_c.php?category_id=4">カテゴリ:シュール</option>
          </select>
<?php
$s = $_SERVER['PHP_SELF'];
$array = explode('2.', $s);
$s = $array[0].".php";
$s = $s."?id=".$_GET["id"];
header( "Location: ".$s );
print $s;
?>