<?php
ini_set('display_errors',1);
require_once __DIR__ . '../User/UserControll.php';
session_start();
require_unlogined_session();
?>
<html>
  <body>
    <?php
		$mysqli = new mysqli("localhost", "ei1425", "ei1425@alumni.hamako-ths.ed.jp", "ei1425");
		if(mysqli_connect_errno()){
			die("MySQL connection error: " . mysqli_connect_error());
		}
		$sql="select * from user where mail='".
		htmlspecialchars($_SESSION["user"])."'";
		if(!($result = $mysqli->query($sql))){
			die("SQL error: " . $mysqli->error);
		}
		echo"USER".SESSION["user"];
		$row = $result->fetch_array(MYSQLI_ASSOC);
		print "<table>";
		$sql2 = "select product_id, COUNT(*) from basket where user_id = '" . $row["user_id"] . "'";
		if(!($result2 = $mysqli->query($sql2))){
			die("SQL error: " . $mysqli->error);
		}
		$data = $result2->fetch_array(MYSQLI_BOTH);
		while ($data = mysql_fetch_array($result)) {
			print "<tr><td>".
			"商品番号" . $data["product_name"] . "</td><td>".
			"オーダー数" . $data["purchase_number"] . "</td></tr>";
		}
		print "</table>";
		$result->close();
		$mysqli->close();
	?>
    <input type="button" value="TOPへ" onClick="location.href='http://alumni.hamako-ths.ed.jp/~ei1425/gohukuya_ren/Cart/TOP.php'">
	<input type="button" value="購入手続きへ" onClick="location.href='http://alumni.hamako-ths.ed.jp/~ei1425/gohukuya_ren/Cart/order.php'">
  </body>
</html>