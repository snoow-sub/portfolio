<?php
ini_set('display_errors',1);
require_once __DIR__ . '../User/UserControll.php';
session_start();
require_unlogined_session();
?>
<html>
<head>
<!--<meta http-equiv="refresh" content="5"; url= http://alumni.hamako-ths.ed.jp/~ei1425/gohukuya_ren/Cart/order.php">-->
</head>
     <body>
       <?php
		ini_set('display_errors',1);
		$mysqli = new mysqli("localhost", "ei1425", "ei1425@alumni.hamako-ths.ed.jp", "ei1425");
		if(mysqli_connect_errno()){
			die("MySQL connection error: " . mysqli_connect_error());
		}
		$sql="select * from user where mail='".
		htmlspecialchars($_SESSION["user"])."'";
		if(!($result = $mysqli->query($sql))){
			die("SQL error: " . $mysqli->error);
		}
		if(($_GET['orders']) < 0){
			die("Order Error: 個数をお確かめください。");
		}
		$row = $result->fetch_array(MYSQLI_ASSOC);
		if($row["mail"]==htmlspecialchars( $_SESSION["user"])){
			print "カートに".$_SESSION["product_name"]."を".$_GET["orders"]."品追加しました。<br>";
			$sql="INSERT INTO basket (user_id, product_id, purchase_number, date, time) VALUES ('".
			$row["user_id"]."','".$_SESSION["product_id"]."','".$_GET["orders"]."','".date("Y-m-d",time())."','"
			.date("G-i-s",time())."')";
			if(!($result = $mysqli->query($sql))){
				die("SQL error: " . $mysqli->error);
			}
			$num = $_SESSION["stock"] - $_GET["orders"];
			if($num < 0){
				die("Order Error: 在庫が足りません。個数を再度入力し直してください。");
			}
		}else{
			print "ERROR.<br>One more order!!";
		}
		$mysqli->close();
	?>
	<input type="button" value="戻る" onClick="location.href='http://alumni.hamako-ths.ed.jp/~ei1425/gohukuya_ren/Cart/TOP.php'">
	<input type="button" value="カートの中身を見る" onClick="location.href='http://alumni.hamako-ths.ed.jp/~ei1425/gohukuya_ren/Cart/cart_open.php'">
	<input type="button" value="購入手続きへ" onClick="location.href='http://alumni.hamako-ths.ed.jp/~ei1425/gohukuya_ren/Cart/order.php'">
	
</body>
</html>