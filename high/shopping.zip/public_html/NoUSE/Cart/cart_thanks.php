<HTML>
<HEAD>
<TITLE>お買い上げありがとうございます - 呉服屋蓮</TITLE>
<link rel="stylesheet" href="/~ei1425/gohukuya_ren/css/cssfont-awesome/css/font-awesome.min.css" type="text/css">
<link rel="stylesheet" href="/~ei1425/gohukuya_ren/css/test2.css" type="text/css">
</HEAD>
<BODY>

  <!--ヘッダー部分 - ここから -->
  <div id="menu_top" align="left">
    <a href="http://alumni.hamako-ths.ed.jp/~ei1425/gohukuya_ren/index.php">
      <img src="http://alumni.hamako-ths.ed.jp/~ei1425/gohukuya_ren/ren.png" class="ren" alt="[写真]" border=0/>
    </a>
    <form name="searchform" id="searchform" method="get" action="search.php">
      <input type="text" name="word" id="keywords" value="" />
      <a href="javascript:void(0)" onclick="document.searchform.submit();return false;"><i class="fa fa-search fa-lg"></i></a>
    </form>
    <table id="menu_list">
      <tr><td><a href="#">マイページ</a></td><td><a href="#">カート(xx)</a></td></tr>
    </table>
  </div>

  <!--ヘッダー部分 - ここまで-->

<div><img src="box.png" alt="[box]" align="middle">
  <p style ="display:inline-block; vertical-align:middle;">
<font size="7" color="#00bfff">お買い上げありがとうございました！</font><br>
<a href="index.php">TOPページに戻る</a>
</p>
</div>

</BODY>
</HTML>
