<?php
ini_set('display_errors',1);
require_once __DIR__ . '../User/UserControll.php';
session_start();
require_unlogined_session();
?>
<html>
<head>
<!--<meta http-equiv="refresh" content="3"; url="http://alumni.hamako-ths.ed.jp/~ei1425/gohukuya_ren/Cart/TOP.php">-->
</head>
	<body>
	<?php
	ini_set('display_errors',1);
	$mysqli = new mysqli("localhost", "ei1425", "ei1425@alumni.hamako-ths.ed.jp", "ei1425");
	if(mysqli_connect_errno()){
		die("MySQL connection error: " . mysqli_connect_error());
	}
	$mysqli->query('SET NAMES utf8' );
	$sql="select * from user where mail='".
	htmlspecialchars($_SESSION["user"])."'";
	if(!($result = $mysqli->query($sql))){
		die("SQL error: " . $mysqli->error);
	}
	$row = $result->fetch_array(MYSQLI_ASSOC);
	$sql6="select count(*) from basket where user_id='".$row["user_id"]."'";
	if(!($result6 = $mysqli->query($sql6))){
		die("SQL error: " . $mysqli->error);
	}
	$count = $result6->fetch_array(MYSQLI_BOTH);
	if($count[0] < 1){
		die("Cart is empty.");
	}else if($row["mail"]==htmlspecialchars( $_SESSION["user"])){
		print "Thank you.<br>";
		do{
			$sql2="select * from basket where user_id='".$row["user_id"]."'";
			if(!($result2 = $mysqli->query($sql2))){
				die("SQL error: " . $mysqli->error);
			}
			$data = $result2->fetch_array(MYSQLI_ASSOC);

			$sql1="select * from product where product_id='".$data["product_id"]."'";
			if(!($result1 = $mysqli->query($sql1))){
				die("SQL error: " . $mysqli->error);
			}
			$row1 = $result1->fetch_array(MYSQLI_ASSOC);
		
			$sql3="INSERT INTO sales_history (user_id, product_id, purchase_number, date, time) VALUES ('".
			$data["user_id"]."','".$data["product_id"]."','".$data["purchase_number"]."','".date("Y-m-d",time())."','"
			.date("G-i-s",time())."')";
			if(!($result3 = $mysqli->query($sql3))){
				die("SQL error: " . $mysqli->error);
			}

			$num = $row1["stock"] - $data["purchase_number"];
			$sql4 = "UPDATE product SET stock = ".$num." where product_id =".$data["product_id"];
			if(!($result4 = $mysqli->query($sql4))){
				die("SQL error: " . $mysqli->error);
			}
			$count[0]--;
		}while($count[0] > 1);
		$sql5 = "DELETE from basket where user_id ='". $row["user_id"] . "'";
		if(!($result5 = $mysqli->query($sql5))){
			die("SQL error: " . $mysqli->error);
		}
	}else{
		print "ERROR.<br>One more order!!";
	}
	$mysqli->close();
	?>
	<input type="button" value="TOP�y�[�W�֖߂�" onClick="location.href='http://alumni.hamako-ths.ed.jp/~ei1425/gohukuya_ren/Cart/TOP.php'">
	</body>
</html>
