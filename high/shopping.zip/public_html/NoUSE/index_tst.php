<html>
<head>
    <title>TOP - 呉服屋蓮</title>
    <link rel="stylesheet" href="/~ei1425/gohukuya_ren/css/font-awesome/css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="/~ei1425/gohukuya_ren/css/test2.css" type="text/css">
</head>
<body>

<?php
/* ヘッダー部分 - ここから */
print<<<HEAD
<div id="menu_top" align="left">
<form style="float:right; margin: 50px 100px 10px 50px;">
<select name="sel2">
<option value="#">(移動したい先名前)</option>
<option value="#">(移動したい先名前)</option>
</select>
<input type=button onClick="top.location.href=sel2.value" value="Jump!">
</form>
  <a href="index.php"><img src="ren.png" class="ren" alt="[写真]" border=0/></a>
  <form name="searchform" id="searchform" method="get" action="search.php">
    <input type="text" name="word" id="keywords" value="" />
    <a href="javascript:void(0)" onclick="document.searchform.submit();return false;"><i class="fa fa-search fa-lg"></i></a>
  </form>
  <table id="menu_list">
    <tr><td><a href="#">マイページ</a></td><td><a href="#">カート(xx)</a></td></tr>
  </table>
</div>
HEAD;
/* ヘッダー部分 - ここまで */

$mysqli =new mysqli("localhost","ei1425","ei1425@alumni.hamako-ths.ed.jp","ei1425");
$mysqli->query('SET NAMES utf8');//文字コード宣言

if(mysqli_connect_errno()){
  die("MySQL connection error: " . mysqli_connect_error());
}
/*TOPページ - ここから*/

/*DBからもってきた商品を並べる*/
$sql = "SELECT product_id,product_name,stock,price,discount,product_pic FROM `product` ORDER BY `product_id` DESC "; //商品IDが新しい順にならべる
if(!($result = $mysqli->query($sql))){
  die("SQL error: ".$mysqli->error);
}

while($row = $result->fetch_array(MYSQLI_NUM)){
  $cnt++;
  $syohin_id[] = $row[0];
  $syohin[] = $row[1];
  $stock[] = $row[2];
  $price[] = $row[3];
  $wari[] = $row[4];
  $s_pic[] = $row[5];
}

for ($i=0; $i < $cnt; $i++) { //商品を表示
  if($wari[$i] != 0) $price[$i] = $price[$i] * $wari[$i];
  echo "
  <div align=center>
    <div style="."float:left;".">
      <table border=0 width=300px height=300px  style = "."table-layout: fixed;".">
        <tr><td>
        <p align=center><img src="."http://alumni.hamako-ths.ed.jp/~ei1425/gohukuya_ren/pic/$s_pic[$i] alt="."商品画像"." style = "."width:200px; height:200px;"."></p>
        <a href="."http://alumni.hamako-ths.ed.jp/~ei1425/gohukuya_ren/syouhin.php?id=$syohin_id[$i]"."><p align=center style="."margin:0".">$syohin[$i]($stock[$i])</p></a>
        <p align=center style="."margin:0".">￥$price[$i]</p>
        </td></tr>
      </table>
    </div>
  </div>
  ";
}
?>

</body>
</html>
