<!DOCTYPE html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<html>
<head>
<title>呉服屋蓮</title>
<link rel="stylesheet" href="/~ei1425/gohukuya_ren/css/syouhin.css" type="text/css">
</head>
<body>

  <!-- <TABLE border="5" cellspacing="10" table frame="box"  align="100px" bgcolor="#ffd0ff" table rules="none">
  <tr><th>名前</th><th>価格</th><th>個数</th></tr> -->

<!-- </table> -->

<?php
ini_set('display_errors',1);

session_start();

$mysqli = new mysqli("localhost", "ei1425", "ei1425@alumni.hamako-ths.ed.jp", "ei1425");
$mysqli->query('SET NAMES utf8' );

if(mysqli_connect_errno()){
die("MySQL connection error: " . mysqli_connect_error());
}

$product_id=(filter_input(INPUT_GET,'id'));
$sql = $mysqli->query("SELECT * FROM product WHERE product_id='$product_id'");
while ($row = $sql->fetch_array(MYSQLI_ASSOC)) {
$name = htmlspecialchars($row['product_name']);
$price = htmlspecialchars($row['price']);
$stock = htmlspecialchars($row['stock']);
$image=htmlspecialchars($row['product_pic']);
$setu=htmlspecialchars($row['Description']);
$a = htmlspecialchars($row["product_id"]);
$b = htmlspecialchars($row["button_1"]);
$c = htmlspecialchars($row["button_2"]);
$d = htmlspecialchars($row["button_3"]);
}
$_SESSION["product_id"]=$product_id;
$_SESSION["product_name"]=$name;
$_SESSION["price"]=$price;
$_SESSION["stock"]=$stock;

echo "
<table border="."1"." align="."left".">
<tr><td>";
echo "<a href="."http://alumni.hamako-ths.ed.jp/~ei1425/gohukuya_ren/pic/product/$image".">";
echo "<img src="."http://alumni.hamako-ths.ed.jp/~ei1425/gohukuya_ren/pic/product/$image"." style="."border:double 5px #808080"." width="."500" ."height="."500"." ></a></td></tr>
</table>";

echo "<table border="."1"." align="."left".">";
echo "<tr><td>$name&nbsp;&nbsp;&nbsp;&nbsp;$price 円</td></tr>";
echo '<tr><td><a class="setu"> '.$setu.'</a></td></tr>';

/* いいねボタン処理 */
if(isset($_POST["button_1"])){
	$kbn = htmlspecialchars($_POST["button_1"], ENT_QUOTES, "UTF-8");
	$s = substr($kbn, 0, 6);
	switch($s){
	case "いい":
		$b += 1;
		$sql = "UPDATE product SET button_1='".$b."' WHERE product_id=".$a;
		if(!($result = $mysqli->query($sql))){
 			print "Error";
			die("SQL error: ".$mysqli->error  );
		}
		break;
	case "爆笑":
		$c += 1;
		$sql = "UPDATE product SET button_2='".$c."' WHERE product_id=".$a;
		if(!($result = $mysqli->query($sql))){
 			print "Error";
			die("SQL error: ".$mysqli->error  );
		}
		break;
	case "ちょ":
		$d += 1;
		$sql = "UPDATE product SET button_3='".$d."' WHERE product_id=".$a;
		if(!($result = $mysqli->query($sql))){
 			print "Error";
			die("SQL error: ".$mysqli->error  );
		}
		break;
	}
}
echo "<tr><td>";
print '<form method="POST" action="">';
print '<input type="submit" name="button_1" value="いいね！('.$b.')">';
print '<input type="submit" name="button_1" value="爆笑('.$c.')" >';
print '<input type="submit" name="button_1" value="ちょっと…('.$d.')" >';
print '</form>';
?>

<form action="http://alumni.hamako-ths.ed.jp/~ei1425/gohukuya_ren/cart.php" method="GET">
個数: <input type="text" name="orders" />
<input type="image" src="http://alumni.hamako-ths.ed.jp/~ei1425/gohukuya_ren/pic/sozai/kounyu.png" alt="送信する" align="middle" height="60%">
</form>
</td></tr>
</table>

<marquee  Bgcolor="#e1f4ff"><img src="http://alumni.hamako-ths.ed.jp/~ei1425/gohukuya_ren/pic/sozai/cart.png" bgcolor="gold" scrollamount="10" style="padding:3px 3px 0px;"><font color="black" >  たくさんかってね    　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　たくさんかってね　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　たくさんかってね　　 　   　 　  　　　　 　 　　  　　 　　　　　　  　  　　　　　　　たくさんかってね　　 　  　    　　  　　  　　  　　  　 　  　　  　　　　　　　　　　たくさんかってね　　　　　   　 　 　　  　 　 　 　 　　　　　　　　　　              たくさんかってね                                                                  </font></marquee>

</body>
</html>
