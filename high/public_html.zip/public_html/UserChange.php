<?php
	ini_set('display_errors',1);
	require_once __DIR__ . '/UserControll.php';
	session_start();

	ini_set('display_errors',1);
	if(!isset($_SESSION["user"])){
		die("<font color='black' size=10    ><center>ログインしてください。</center><br />\n");
	}
    $mysqli = new mysqli("mysql1.php.starfree.ne.jp", "tibineko923_user", "yuu0923ki", "tibineko923_data");
	$mysqli->query('SET NAMES utf8');
	if(mysqli_connect_errno()){
		die("MySQL connection error: " . mysqli_connect_error());
	}

	$original_sql = "select * from user where mail='".
	htmlspecialchars($_SESSION["user"])."'";
	if(!($original_result = $mysqli->query($original_sql))){
		die("SQL error: " . $mysqli->error);
	}
	$original = $original_result->fetch_array(MYSQLI_ASSOC);
	$birth = explode("-", $original["birthday"]);

	$user_family = filter_input(INPUT_POST,'user_family');
	$user_name = filter_input(INPUT_POST,'user_name');
	$phone_number = filter_input(INPUT_POST,'phone_number');
	$place_yubin = filter_input(INPUT_POST,'place_yubin');
	$place_address = filter_input(INPUT_POST,'place_address');
	$year = filter_input(INPUT_POST,'year');
	$month = filter_input(INPUT_POST,'month');
	$day = filter_input(INPUT_POST,'day');
	$nickname = filter_input(INPUT_POST,'nickname');
	$email = filter_input(INPUT_POST,'email');
	$password = filter_input(INPUT_POST,'password');
	$repassword = filter_input(INPUT_POST,'repassword');
	
	if($_SERVER['REQUEST_METHOD'] === 'POST'){
		$user_search_sql = "SELECT mail FROM user WHERE mail='$email'";
		$user_search_result = $mysqli->query($user_search_sql);
		if($user_search_result === false){
			die("SQL error: ".$mysqli->error);
		}
		$row = $user_search_result->fetch_array(MYSQLI_ASSOC);
		if($password != $repassword){
			$_SESSION['message'] = 'パスワードが一致していません';
		}else{
			$password = password_hash($password,PASSWORD_DEFAULT);
			if(strlen($day) == 1) $day = '0' . $day;
			$birthday = $year . '/' . $month . '/' . $day;
			print $day . ' ' . $birthday;
			$user_insert_sql="UPDATE user set pass = '" . $password . "', user_family = '" . $user_family . "', user_name = '" . $user_name . "', phone_number = '" . $phone_number . "', place_yubin = '" . $place_yubin . "', place_address = '" . $place_address . "', mail = '" . $email . "', nickname = '" . $nickname . "', birthday = '" . $birthday . "' where user_id = '" . $original["user_id"] . "'";
			$user_insert_result = $mysqli->query($user_insert_sql);
			if($user_insert_result === false){
				die("SQL error: ".$mysqli->error);
			}
			$_SESSION['message'] = 'ユーザー情報を変更しました。';
			redirect_to('UserLogin.php');
			exit;
		}
		$user_search_result->close();
	}

	$mysqli->close();
	header('Content-Type: text/html; charset=UTF-8');
?>

<!DOCTYPE html>
<html>
  <head>
    <title>呉服屋こーかとん</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1/jquery-ui.min.js"></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1/i18n/jquery.ui.datepicker-ja.min.js"></script>
    <script src="https://ajaxzip3.github.io/ajaxzip3.js" charset="UTF-8"></script>
    <link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1/themes/ui-lightness/jquery-ui.css" >
    <link rel="stylesheet" href="./css/UserCreate.css" type="text/css">
    <link rel="stylesheet" href="./css/static.css" type="text/css">
  <link rel="stylesheet" href="./css/font-awesome/css/font-awesome.min.css" type="text/css">
    <script>
      /* 読み込み時と画面サイズ変更時に処理をする */
      $(window).on('load resize', function(){
        var windowsize = $('body').width();
	if(windowsize < 471){
          $('img#shoplogo').css('margin-left','150px');
	  $('div#outside_frame').css('margin','10px');
	} else {
	  $('img#shoplogo').css('margin-left',windowsize/2-85+'px');
	  $('div#outside_frame').css('margin-left',windowsize/2-225+'px');
	  $('div#outside_frame').css('margin-right',windowsize/2-225+'px');
	}
      });
    </script>
  </head>
  <body>
    <a href="./index.php">
      <img id="shoplogo" src="./pic/sozai/logo.png"></a>
    <div id="outside_frame">
    <h1><span>アカウント変更</span></h1>
    <?php
    if(!empty($_SESSION['message'])) {
        echo '<p id="warning"><i class="fa fa-warning"></i> '.$_SESSION['message'].'</p>';
        unset($_SESSION['message']);
    }
	?>
	<form action="" method="post">
    <div id="input_holder"><div id="label">名前</div><input type="text" name="user_family" value="<?php echo $original["user_family"] ?>" class="text_name" placeholder="姓" required><input type="text" name="user_name" value="<?php echo $original["user_name"] ?>"class="text_name" placeholder="名" required></div>
    <div id="input_holder"><div id="label">電話番号</div><input type="text" name="phone_number" value="<?php echo $original["phone_number"] ?>" class="textbx" required></div>
    <div id="input_holder"><div id="label">郵便番号 (7桁)</div><input type="text" name="place_yubin" value="<?php echo $original["place_yubin"] ?>" class="textbx" maxlength="7" onKeyUp="AjaxZip3.zip2addr(this,'','place_address','place_address');" required></div>
    <div id="input_holder"><div id="label">住所</div><input type="text" name="place_address" value="<?php echo $original["place_address"] ?>" class="textbx" placeholder="郵便番号入力で自動取得" required></div>
    <div id="input_holder"><div id="label">誕生日</div><select name="month" value="<?php echo $birth[1] ?>">
	<option value="" disabled selected>month</option>
	<?php
	for($i = 1; $i <= 12; $i++){
		if($i >= 10){
			echo "<option value='".$i."'>".$i."月</option>";
		}else{
			echo "<option value='0".$i."'>".$i."月</option>";
		}
    }
	?>
	</select>
	<input type="text" name="day" value="<?php echo $birth[2] ?>" class="text_date" placeholder="day" maxlength="2" required><input type="text" name="year" value="<?php echo $birth[0] ?>" class="text_date" placeholder="year" maxlength="4" required></div>
    <div id="input_holder"><div id="label">ニックネーム</div><input type="text" name="nickname" value="<?php echo $original["nickname"] ?>" class="textbx" required></div>
    <div id="input_holder"><div id="label">E-Mail (ログインID)</div><input type="text" name="email" value="<?php echo $original["mail"] ?>" class="textbx" required></div>
    <div id="input_holder"><div id="label">パスワード</div><input type="password" name="password" class="textbx" required></div>
    <div id="input_holder"><div id="label">パスワード再入力 (確認用)</div><input type="password" name="repassword" class="textbx" required></div>
    <input type="submit" id="submit_button" value="変更する">
    </form>
    </div>
  </body>
</html>
