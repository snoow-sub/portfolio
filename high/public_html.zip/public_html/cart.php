<html>
<head>
<title>呉服屋こーかとん</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<link rel="stylesheet" href="./css/cart.css" type="text/css">
<link rel="stylesheet" href="./css/mainmenu.css" type="text/css">
<link rel="stylesheet" href="./css/font-awesome/css/font-awesome.min.css" type="text/css">
     <!--<meta http-equiv="refresh" content="5"; url= order.php">-->
</head>
<body>
<?php
ini_set('display_errors',1);
require_once __DIR__ . '/UserControll.php';
session_start();
require_logined_session();
$mysqli = new mysqli("mysql1.php.starfree.ne.jp", "tibineko923_user", "yuu0923ki", "tibineko923_data");
if(mysqli_connect_errno()){
    die("MySQL connection error: " . mysqli_connect_error());
}
if(!isset($_SESSION["user"])){
	$cart = 0; //カートに入れた商品の数を取得
}else{
	$sql="select * from user where mail='".
	htmlspecialchars($_SESSION["user"])."'";
	if(!($result = $mysqli->query($sql))){
		die("SQL error: " . $mysqli->error);
	}
	$row = $result->fetch_array(MYSQLI_ASSOC);
	$sql2="select count(*) from basket where user_id='".$row["user_id"]."'";
	if(!($result2 = $mysqli->query($sql2))){
		die("SQL error: " . $mysqli->error);
	}
	$count = $result2->fetch_array(MYSQLI_BOTH);
	$cart = $count[0]; //カートに入れた商品の数を取得
}
?>
<script>
 /* 読み込み時と画面サイズ変更時に処理をする */
$(window).on('load resize', function(){
        var windowsizeW = $(window).width();
        if(windowsizeW < 327){
            $('div#mainmenu').css('height','276px');
        } else if(windowsizeW < 587){
            $('div#mainmenu').css('height','207px');
        } else if(windowsizeW < 807){
            $('div#mainmenu').css('height','138px');
        } else {
            $('div#mainmenu').css('height','69px');
        }
    });
</script>
<div id="mainmenu">
    <a href="./index.php"><img id="shoplogo" src="./pic/sozai/logo.png"></a>
    <div id="menu">
    <div id="right_items">
    <form name="rankingform" id="rankingform" method="get" action="#">
    <select id="ranking_select" name="sel2">
    <option value="./rank.php">いいねランキング</option>
    <option value="./search_c.php?category_id=1">カテゴリ:ネタ</option>
    <option value="./search_c.php?category_id=2">カテゴリ:アニメ</option>
    <option value="./search_c.php?category_id=3">カテゴリ:ゴッド</option>
    <option value="./search_c.php?category_id=4">カテゴリ:シュール</option>
    </select>
    <input type="button" id="jumpbutton" onClick="top.location.href=sel2.value" value="Jump!!">
    </form>
    <form name="searchform" id="searchform" method="get" action="./search.php">
    <input type="text" name="word" id="keywords" value="" />
    <a href="javascript:void(0)" onclick="document.searchform.submit();return false;"><i class="fa fa-search fa-lg"></i></a>
    </form>
    </div>
    <div id="user_items">
    <ul>
    <li>
    <a href='UserMyPage.php'><i class='fa fa-user'></i>Myページ</a>
    </li>
    <li>
<right>
<?php
    $tokentmp = h(generate_token());
echo "<a href='UserLogout.php?token=".$tokentmp."'><i class='fa fa-sign-out'></i>ログアウト</a>";
?>
</li>
</ul>
</div>
<div id="menu_list">
	<ul>
    <li><a href="./cart_open.php"><i class="fa fa-shopping-cart"></i><br>カート(<?php echo $cart; ?>)</a></li>
	</ul>
    </div>
    </div>
    </div>
<?php
	if(!isset($_SESSION["user"])){
		echo "	<font color='black' size=10><center>ログインしてください。</center><br />\n";
	}else{
		$sql = "select * from product where product_id='".
        htmlspecialchars($_SESSION["product_id"])."'";
		if(!($result = $mysqli->query($sql))){
			die("SQL error: " . $mysqli->error);
		}
		$row = $result->fetch_array(MYSQLI_ASSOC);
		if($row["product_id"]==htmlspecialchars( $_SESSION["product_id"])){
			$image=$row["product_pic"];
			echo "<div align=center><img src="."./pic/product/$image"."  width="."300" ."height="."300"." ></div>";
		}
		if(!isset($_GET["orders"])){
			echo "<font color='black' size=10><center>商品を選択してください。</center><br />\n";
		}else if($_GET["orders"] <= 0){
			echo "<font color='black' size=10><center>商品の数を確認してください。</center><br />\n";
		}else{
			$sql="select * from user where mail='".
			htmlspecialchars($_SESSION["user"])."'";
			if(!($result = $mysqli->query($sql))){
				die("SQL error: " . $mysqli->error);
			}
			$row = $result->fetch_array(MYSQLI_ASSOC);
			if($row["mail"]==htmlspecialchars( $_SESSION["user"])){
				$num = $_SESSION["stock"] - $_GET["orders"];
				if($num < 0){
					echo "<font color='black' size=10><center>在庫が足りません。個数を再度入力し直してください。</center><br />\n";
				}else{
					print "<br><span style='font-size:300%;' style='text-align:right';><center>カートに&nbsp;".$_SESSION["product_name"]."&nbsp;を&nbsp;".$_GET["orders"]."&nbsp;品追加しました。</center><br></span>";
					$sql="INSERT INTO basket (user_id, product_id, purchase_number, date, time) VALUES ('".
					$row["user_id"]."','".$_SESSION["product_id"]."','".$_GET["orders"]."','".date("Y-m-d",time())."','"
					.date("H:i:s",time())."')"; // CURRENT_TIMESTAMP
					if(!($result = $mysqli->query($sql))){
						die("SQL error: " . $mysqli->error);
					}
				}
			}else{
				print "ERROR.<br>One more order!!";
			}
			$mysqli->close();
		}
	}

?>
</right>
<br>
<div align=center>
  <input type="button" class="naka" value="カートの中身を見る" onClick="location.href='./cart_open.php'">
	<input type="button" class="kou" value="購入手続きへ" onClick="location.href='./order.php'">
	<input type="button" class="tudu" value="買い物を続ける" onClick="location.href='./index.php'"></br>
</div>
</body>
</html>

<div style="text-align:center">
