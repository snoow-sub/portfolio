<html>
  <body>
    <?php
ini_set('display_errors',1);
session_start();
		if(!isset($_SESSION['user'])){
			print "ログインしてください。";
		}else{
			$mysqli = new mysqli("localhost", "ei1425", "ei1425@alumni.hamako-ths.ed.jp", "ei1425");
            $mysqli->query('SET NAMES utf8');
			if(mysqli_connect_errno()){
				die("MySQL connection error: " . mysqli_connect_error());
			}
			$sql="select * from user where mail='".
			htmlspecialchars($_SESSION["user"])."'";
			if(!($result = $mysqli->query($sql))){
				die("SQL error: " . $mysqli->error);
			}
			print "USER : ". $_SESSION["user"] . "<br>";
			$row = $result->fetch_array(MYSQLI_ASSOC);
			$sql2 = "select * from sales_history where user_id = '" . $row["user_id"] . "'";
			if(!($result2 = $mysqli->query($sql2))){
				die("SQL error: " . $mysqli->error);
			}
			while ($data = $result2->fetch_array(MYSQLI_ASSOC)) {
				$sql3 = "select * from product where product_id = '" . $data["product_id"] . "'";
				if(!($result3 = $mysqli->query($sql3))){
					die("SQL error: " . $mysqli->error);
				}
				$data2 = $result3->fetch_array(MYSQLI_ASSOC);
				print "<table bgcolor='#eeeeee'>";
				print "<tr><td>".
				"[商品名]</td><td>" . $data2["product_name"] . "</td></tr><tr><td>".
				"[オーダー数]</td><td>" . $data["purchase_number"] . "</td></tr><tr><td>".
				"[日付]</td><td>" . $data["date"] . "</td></tr>";
				print "</table>";
			}
			$result->close();
			$mysqli->close();
		}
	?>
    <input type="button" value="TOPへ" onClick="location.href='http://alumni.hamako-ths.ed.jp/~ei1425/gohukuya_ren/index.php'">
	<input type="button" value="購入手続きへ" onClick="location.href='http://alumni.hamako-ths.ed.jp/~ei1425/gohukuya_ren/order.php'">
  </body>
</html>