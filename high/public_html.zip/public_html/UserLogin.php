<?php
ini_set('display_errors',1);
require_once __DIR__ . '/UserControll.php';
session_start();
require_unlogined_session();

/* データベースとの接続 */
$mysqli = new mysqli("mysql1.php.starfree.ne.jp", "tibineko923_user", "yuu0923ki", "tibineko923_data");
if(mysqli_connect_errno()){
    die("MySQL connection error: " . mysqli_connect_error());
}

$email = filter_input(INPUT_POST,'email');
$password = filter_input(INPUT_POST,'password');

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    /* 入力されたユーザのデータをDBから取ってくる */
    $user_search_sql = "SELECT pass FROM user WHERE mail = '$email'";
    $user_search_result = $mysqli->query($user_search_sql);
    if($user_search_result === false){
        die("SQL error: ".$mysqli->error);
    }
    if($row = $user_search_result->fetch_array(MYSQLI_ASSOC)){
        if(validate_token(filter_input(INPUT_POST,'token')) &&
           password_verify($password,$row['pass'])){
            session_regenerate_id(true);
            $_SESSION['user'] = $email;

            $user_search_result->close();
            $mysqli->close();

            header('Location: UserMyPage.php');
            exit;
        }
        $_SESSION['message'] = 'ユーザとパスワードが正しくありません';
    } else {
    	$_SESSION['message'] = '入力されたユーザは登録されていません';
    }
}

$mysqli->close();
header('Content-Type: text/html; charset=UTF-8');
?>

<!DOCTYPE html>
<html>
  <head>
    <title>呉服屋こーかとん</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <link rel="stylesheet" href="./css/UserLogin.css" type="text/css">
    <link rel="stylesheet" href="./css/static.css" type="text/css">
<link rel="stylesheet" href="./css/font-awesome/css/font-awesome.min.css" type="text/css">
    <script>
      /* 読み込み時と画面サイズ変更時に処理をする */
      $(window).on('load resize', function(){
        var windowsizeW = $(window).width();
	var windowsizeH = $(window).height();
	$('div#allitems').css('width',windowsizeW+'px');
	$('div#allitems').css('height',windowsizeH+'px');
	if(windowsizeW < 471){
          $('div#leftside_frame').css('display','none');
  	  $('div#rightside_frame').css('left','0px');
 	  $('div#rightside_frame').css('margin-left','0px');
	  $('div#rightside_frame').css('margin-right','0px');
	  $('div#rightside_frame').css('background-color','#E6E6E6');
	} else if(windowsizeW < 980){
	  $('div#leftside_frame').css('display','none');
	  $('div#rightside_frame').css('left','0px');
	  $('div#rightside_frame').css('margin-left',windowsizeW/2-225+'px');
	  $('div#rightside_frame').css('margin-right',windowsizeW/2-225+'px');
	  $('div#rightside_frame').css('background-color','#E6E6E6');
	} else {
	  $('div#leftside_frame').css('display','inline');
 	  $('div#rightside_frame').css('margin-left','0px');
	  $('div#rightside_frame').css('margin-right','0px');
  	  $('div#leftside_frame').css('left',windowsizeW/2-510+'px');
	  $('div#rightside_frame').css('left',windowsizeW/2+'px');
	  $('div#rightside_frame').css('background-color','#fff');
	}
      });
    </script>
  </head>
  <body>
    <div id="allitems">
    <div id="leftside_frame">
      <img id="shoplogo" src="./pic/sozai/logo.png">
      <p>～Tシャツであなたの心を表現しませんか???～</p>
    </div>
    <div id="rightside_frame">
    <div id="create_button"><a href="UserCreate.php"><i class="fa fa-angle-double-right"></i>新しくユーザ登録する方はこちら</a></div>
    <h1>Login</h1>
    <?php
    if(!empty($_SESSION['message'])) {
      echo '<p id="warning"><i class="fa fa-warning"></i> '.$_SESSION['message'].'</p>';
      unset($_SESSION['message']);
    }
    ?>
    <form action="" method="post">
      <div id="input_holder"><div id="label">ログインID (E-Mail)</div><input type="text" name="email" class="textbx" required></div>
      <div id="input_holder"><div id="label">パスワード</div><input type="password" name="password" class="textbx" required></div>
    <?php
      $tokentmp = h(generate_token());
      echo "<input type='hidden' name='token' value='".$tokentmp."'>"."\n";
    ?>
    <input type="submit" id="submit_button" value="入店">
    </form>
    </div>
    </div>
    </body>
</html>
