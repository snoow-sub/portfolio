﻿<html>
<head>
  <title>ランキング - 呉服屋こーかとん</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="./css/mainmenu.css">
<link rel="stylesheet" type="text/css" href="./css/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="./css/syouhin.css">
<style type="text/css">
.table1 {
  border-collapse: collapse;
}
a { text-decoration:none;}
a:link {color:#404040;}
a:visited{color:#202020;}
a:hover{text-decoration:underline;
        color:#808080;}
a:active{color:#c0c0c0;}
</style>
</head>
<body>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<?php
ini_set('display_errors',1);
require_once __DIR__ . '/UserControll.php';
session_start();
require_logined_session();

$mysqli = new mysqli("mysql1.php.starfree.ne.jp", "tibineko923_user", "yuu0923ki", "tibineko923_data");
$mysqli->query('SET NAMES utf8' );

if(mysqli_connect_errno()){
die("MySQL connection error: " . mysqli_connect_error());
}

if(!isset($_SESSION["user"])){
	$cart = 0; //カートに入れた商品の数を取得
}else{
	$sql="select * from user where mail='".
	htmlspecialchars($_SESSION["user"])."'";
	if(!($result = $mysqli->query($sql))){
		die("SQL error: " . $mysqli->error);
	}
	$row = $result->fetch_array(MYSQLI_ASSOC);
	$sql2="select count(*) from basket where user_id='".$row["user_id"]."'";
	if(!($result2 = $mysqli->query($sql2))){
		die("SQL error: " . $mysqli->error);
	}
	$count = $result2->fetch_array(MYSQLI_BOTH);
	$cart = $count[0]; //カートに入れた商品の数を取得
}
?>

    <script>
      /* 読み込み時と画面サイズ変更時に処理をする */
      $(window).on('load resize', function(){
        var windowsizeW = $(window).width();
	if(windowsizeW < 327){
	  $('div#mainmenu').css('height','276px');
	} else if(windowsizeW < 587){
	  $('div#mainmenu').css('height','207px');
	} else if(windowsizeW < 807){
	  $('div#mainmenu').css('height','138px');
	} else {
	  $('div#mainmenu').css('height','69px');
	}
      });
    </script>
    <div id="mainmenu">
      <a href="./index.php"><img id="shoplogo" src="./pic/sozai/logo.png"></a>
      <div id="menu">
      <div id="right_items">
        <form name="rankingform" id="rankingform" method="get" action="#">
          <select id="ranking_select" name="sel2">
	    <option value="./rank.php">いいねランキング</option>
	    <option value="./search_c.php?category_id=1">カテゴリ:ネタ</option>
	    <option value="./search_c.php?category_id=2">カテゴリ:アニメ</option>
	    <option value="./search_c.php?category_id=3">カテゴリ:ゴッド</option>
	    <option value="./search_c.php?category_id=4">カテゴリ:シュール</option>
          </select>
          <input type="button" id="jumpbutton" onClick="top.location.href=sel2.value" value="Jump!!">
        </form>
        <form name="searchform" id="searchform" method="get" action="./search.php">
          <input type="text" name="word" id="keywords" value="" placeholder="検索" style="height:30px;" />
	  <a href="javascript:void(0)" onclick="document.searchform.submit();return false;"><i class="fa fa-search fa-lg"></i></a>
        </form>
      </div>
      <div id="user_items">
        <ul>
	  <li>
	    <a href='UserMyPage.php'><i class='fa fa-user'></i>Myページ</a>
	  </li>
	  <li>
          <?php
            $tokentmp = h(generate_token());
            echo "<a href='UserLogout.php?token=".$tokentmp."'><i class='fa fa-sign-out'></i>ログアウト</a>";
          ?>
	  </li>
	</ul>
      </div>
      <div id="menu_list">
	<ul>
	  <li><a href="./cart_open.php"><i class="fa fa-shopping-cart"></i><br>カート(<?php echo $cart; ?>)</a></li>
	</ul>
      </div>
    </div>
    </div>

<div align=center>
<?php

$mysqli->query('SET NAMES utf8');//文字コード宣言
$mysqli = new mysqli("mysql1.php.starfree.ne.jp", "tibineko923_user", "yuu0923ki", "tibineko923_data");
if(mysqli_connect_errno()){
  die("MySQL connection error: " . mysqli_connect_error());
}
echo "&nbsp;<br><br><br>";
print "<table class='table1' border=0 align="."left".">";
print "<tr><td width=100px><font size='5'>&nbsp;</font></td></tr>";
for($i=1; $i<=5; $i+=1){
  print "<tr><td height=303px>";
  print"<p align=center><img src="."./pic/sozai/rank_$i.png alt="."商品画像"." style = "."width:100px;"."></p>";
  print "</td></tr>";
}

print "<table class='table1' border=0 align="."left".">";
/*DBからもってきた商品を並べる*/
$sql = "SELECT product_id,product_name,stock,price,discount,product_pic FROM `product` ORDER BY `button_1` DESC "; //いいねが多い順にならべる
if(!($result = $mysqli->query($sql))){
  die("SQL error: ".$mysqli->error);
}

for($i=0; $i<5; $i+=1){
  $row = $result->fetch_array(MYSQLI_NUM);
  $syohin_id[$i] = $row[0];
  $syohin[$i] = $row[1];
  $stock[$i] = $row[2];
  $price[$i] = $row[3];
  $wari[$i] = $row[4];
  $s_pic[$i] = $row[5];
}
print "<tr><td align=center>";
print "<font size='5'><u>いいね!</u></font>";
print "</td></tr>";
for($i=0; $i<5; $i+=1){
  print "<tr><td>";
  if($wari[$i] != 0) $price[$i] = $price[$i] * $wari[$i];
  echo "
  <div align=center>
    <div style="."float:left;".">
      <table border=0 width=300px height=300px  style = "."table-layout: fixed;".">
        <tr><td>
        <p align=center><a href="."./syouhin.php?id=$syohin_id[$i]"."><img src="."./pic/product/$s_pic[$i] alt="."商品画像"." style = "."width:200px; height:200px;"."></a></p>
        <a href="."./syouhin.php?id=$syohin_id[$i]"."><p align=center style="."margin:0".">$syohin[$i]($stock[$i])</p></a>
        <p align=center style="."margin:0".">￥$price[$i]</p>
        </td></tr>
      </table>
    </div>
  </div>
  ";
  print "</td></tr>";
}
print "</table>";


print "<table class='table1' border=0 align="."left".">";
/*DBからもってきた商品を並べる*/
$sql = "SELECT product_id,product_name,stock,price,discount,product_pic FROM `product` ORDER BY `product`.`button_2` DESC "; //爆笑が多い順にならべる
if(!($result = $mysqli->query($sql))){
  die("SQL error: ".$mysqli->error);
}

for($i=0; $i<5; $i+=1){
  $row = $result->fetch_array(MYSQLI_NUM);
  $syohin_id[$i] = $row[0];
  $syohin[$i] = $row[1];
  $stock[$i] = $row[2];
  $price[$i] = $row[3];
  $wari[$i] = $row[4];
  $s_pic[$i] = $row[5];
}

print "<tr><td align=center>";
print "<font size='5'><u>爆笑</u></font>";
print "</td></tr>";
for($i=0; $i<5; $i+=1){
  print "<tr><td>";
  if($wari[$i] != 0) $price[$i] = $price[$i] * $wari[$i];
  echo "
  <div align=center>
    <div style="."float:left;".">
      <table border=0 width=300px height=300px  style = "."table-layout: fixed;".">
        <tr><td>
        <p align=center><a href="."./syouhin.php?id=$syohin_id[$i]"."><img src="."./pic/product/$s_pic[$i] alt="."商品画像"." style = "."width:200px; height:200px;"."></a></p>
        <a href="."./syouhin.php?id=$syohin_id[$i]"."><p align=center style="."margin:0".">$syohin[$i]($stock[$i])</p></a>
        <p align=center style="."margin:0".">￥$price[$i]</p>
        </td></tr>
      </table>
    </div>
  </div>
  ";
  print "</td></tr>";
}
print "</table>";


print "<table class='table1' border=0 align="."left".">";
/*DBからもってきた商品を並べる*/
$sql = "SELECT product_id,product_name,stock,price,discount,product_pic FROM `product` ORDER BY `product`.`button_3` DESC "; //ちょっとが多い順にならべる
if(!($result = $mysqli->query($sql))){
  die("SQL error: ".$mysqli->error);
}

for($i=0; $i<5; $i+=1){
  $row = $result->fetch_array(MYSQLI_NUM);
  $syohin_id[$i] = $row[0];
  $syohin[$i] = $row[1];
  $stock[$i] = $row[2];
  $price[$i] = $row[3];
  $wari[$i] = $row[4];
  $s_pic[$i] = $row[5];
}

print "<tr><td align=center>";
print "<font size='5'><u>ちょっと...</u></font>";
print "</td></tr>";
for($i=0; $i<5; $i+=1){
  print "<tr><td>";
  if($wari[$i] != 0) $price[$i] = $price[$i] * $wari[$i];
  echo "
    <div style="."float:left;".">
      <table border=0 width=300px height=300px  style = "."table-layout: fixed;".">
        <tr><td>
        <p align=center><a href="."./syouhin.php?id=$syohin_id[$i]"."><img src="."./pic/product/$s_pic[$i] alt="."商品画像"." style = "."width:200px; height:200px;"."></a></p>
        <a href="."./syouhin.php?id=$syohin_id[$i]"."><p align=center style="."margin:0".">$syohin[$i]($stock[$i])</p></a>
        <p align=center style="."margin:0".">￥$price[$i]</p>
        </td></tr>
      </table>
    </div>
  </div>
  ";
  print "</td></tr>";
}
print "</table>";

?>

</body>
</html>
