<?php
ini_set('display_errors',1);
require_once __DIR__ . '/UserControll.php';
session_start();
require_logined_session();

/* データベースとの接続 */
$mysqli = new mysqli("mysql1.php.starfree.ne.jp", "tibineko923_user", "yuu0923ki", "tibineko923_data");
$mysqli->query('SET NAMES utf8');
if(mysqli_connect_errno()){
    die("MySQL connection error: " . mysqli_connect_error());
}

$email = $_SESSION['user'];

$user_get_sql = "SELECT * FROM user WHERE mail='$email'";
$user_get_result = $mysqli->query($user_get_sql);
if($user_get_result === false){
  die("SQL error: ".$mysqli->error);
}
if($row = $user_get_result->fetch_array(MYSQLI_ASSOC)){
  $nickname = $row['nickname'];
  $birthday = $row['birthday'];
  $birthday = substr($birthday,0,4).'年'.substr($birthday,5,2).'月'.substr($birthday,8,2).'日';
}

if(!isset($_SESSION["user"])){
	$cart = 0; //カートに入れた商品の数を取得
}else{
	$sql="select * from user where mail='".
	htmlspecialchars($_SESSION["user"])."'";
	if(!($result = $mysqli->query($sql))){
		die("SQL error: " . $mysqli->error);
	}
	$row = $result->fetch_array(MYSQLI_ASSOC);
	$sql2="select count(*) from basket where user_id='".$row["user_id"]."'";
	if(!($result2 = $mysqli->query($sql2))){
		die("SQL error: " . $mysqli->error);
	}
	$count = $result2->fetch_array(MYSQLI_BOTH);
	$cart = $count[0]; //カートに入れた商品の数を取得
}

if(!isset($_SESSION['user'])){
    print "ログインしてください。";
}else{
    $sql="select * from user where mail='".
        htmlspecialchars($_SESSION["user"])."'";
    if(!($result = $mysqli->query($sql))){
        die("SQL error: " . $mysqli->error);
    }
    $row = $result->fetch_array(MYSQLI_ASSOC);
    $sql2 = "select * from sales_history where user_id = '" . $row["user_id"] . "' ORDER BY date DESC , time DESC";
    if(!($result2 = $mysqli->query($sql2))){
        die("SQL error: " . $mysqli->error);
    }
    $result->close();
}
?>

<!DOCTYPE html>
<html>
  <head>
    <title>呉服屋こーかとん</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <link rel="stylesheet" href="./css/UserMyPage.css" type="text/css">
    <link rel="stylesheet" href="./css/mainmenu.css" type="text/css">
    <link rel="stylesheet" href="./css/font-awesome/css/font-awesome.min.css" type="text/css">
  </head>
  <body>
    <script>
      /* 読み込み時と画面サイズ変更時に処理をする */
      $(window).on('load resize', function(){
        var windowsizeW = $(window).width();
	if(windowsizeW < 327){
	  $('div#mainmenu').css('height','276px');
	} else if(windowsizeW < 587){
	  $('div#mainmenu').css('height','207px');
	} else if(windowsizeW < 807){
	  $('div#mainmenu').css('height','138px');
	} else {
	  $('div#mainmenu').css('height','69px');
	}
	$('div#sales_history').css('width',windowsizeW-380+'px');
      });
    </script>
    <div id="mainmenu">
      <a href="./index.php"><img id="shoplogo" src="./pic/sozai/logo.png"></a>
      <div id="menu">
      <div id="right_items">
        <form name="rankingform" id="rankingform" method="get" action="#">
          <select id="ranking_select" name="sel2">
	    <option value="./rank.php">いいねランキング</option>
	    <option value="./search_c.php?category_id=1">カテゴリ:ネタ</option>
	    <option value="./search_c.php?category_id=2">カテゴリ:アニメ</option>
	    <option value="./search_c.php?category_id=3">カテゴリ:ゴッド</option>
	    <option value="./search_c.php?category_id=4">カテゴリ:シュール</option>
          </select>
          <input type="button" id="jumpbutton" onClick="top.location.href=sel2.value" value="Jump!!">
        </form>
        <form name="searchform" id="searchform" method="get" action="./search.php">
          <input type="text" name="word" id="keywords" value="" placeholder="検索"/>
	  <a href="javascript:void(0)" onclick="document.searchform.submit();return false;"><i class="fa fa-search fa-lg"></i></a>
        </form>
      </div>
      <div id="user_items">
        <ul>
	  <li>
	    <a href='UserMyPage.php'><i class='fa fa-user'></i>Myページ</a>
	  </li>
	  <li>
          <?php
            $tokentmp = h(generate_token());
            echo "<a href='UserLogout.php?token=".$tokentmp."'><i class='fa fa-sign-out'></i>ログアウト</a>";
          ?>
	  </li>
	</ul>
      </div>
      <div id="menu_list">
	<ul>
	  <li><a href="./cart_open.php"><i class="fa fa-shopping-cart"></i><br>カート(<?php echo $cart; ?>)</a></li>
	</ul>
      </div>
    </div>
    </div>
    <div id="mypage">
      <div id="user_info">
        <h2><i class="fa fa-user-circle-o"></i><?php echo $nickname; ?></h2>
        <h3><i class="fa fa-envelope"></i><?php echo $email; ?></h3>
        <h3><i class="fa fa-birthday-cake"></i><?php echo $birthday; ?></h3>
        <div id="change_button"><a href="UserChange.php"><i class="fa fa-angle-double-right"></i>ユーザの設定を変更する</a></div>
      </div>
      <div id="sales_history">
      <h2><i class="fa fa-shopping-basket"></i>購入履歴</h2>
      <?php
        $cnt = -1;
	$nowDate = "";
	$totalprice = 0;
	$totalorder = 0;
        while ($data = $result2->fetch_array(MYSQLI_ASSOC)) {
          $sql3 = "select * from product where product_id = '" . $data["product_id"] . "'";
          if(!($result3 = $mysqli->query($sql3))){
            die("SQL error: " . $mysqli->error);
          }
          $data2 = $result3->fetch_array(MYSQLI_ASSOC);
	  $DateTime = $data["date"] . " " . $data["time"];
	  if($DateTime != $nowDate) {
	    $nowDate = $DateTime;
	    if($cnt === -1) $cnt = 0;
	    if($cnt !== 0){
	      print "<p id='totalinfo'><span>[お買い上げ金額] : " . $totalorder . "個 " . $totalprice . "円</span></p>";
	      $totalorder = 0;
	      $totalprice = 0;
	      print "</div>";
	      if($cnt === 5) break;
	    }
	    $cnt++;
	    print "<div id='onesale'><h4>[日付] : " . $nowDate . "</h4>";
	  }
	  print "<div><img id='product_pic' src='pic/product/" . $data2["product_pic"]  . "'>";
	  print "<p>[商品名] : " . $data2["product_name"] . "</p>";
          print "<p>[オーダー数] : " . $data["purchase_number"] . "</p>";
	  print "<p>[値段] : " . $data2["price"] . " × " . $data["purchase_number"] . " = " . $data2["price"]*intval($data["purchase_number"]) . "</p></div>";
	  $totalorder += intval($data["purchase_number"]);
	  $totalprice += $data2["price"]*intval($data["purchase_number"]);
	  $result3->close();
        }
	if($cnt === -1) print "<p>購入した履歴がありません</p>";
        $result2->close();
        $mysqli->close();
      ?>
      </div>
    </div>
  </body>
</html>
