#include<stdio.h>
#include<stdlib.h>

void Hanoi(int n, char from, char work, char to);

int main(int argc, char *argv[]){
  
  int i, n;
  static int hanoi[100][100] = { 0 };
  
  if(argc != 2){
    fprintf(stderr, "Usage: %s <number of disk>", argv[0]);
    exit(1);
  }
  sscanf(argv[1], "%d", &n);
  if(*(argv[1] + 0) > 100){
    printf("Sorry. Can't do this.\n");
    exit(2);
  }
  for(i = 1; i <= n; i++){
    hanoi[1][i] = i;
  }
  Hanoi(n, 1, 2, 3);
  
  return(0);
}


void Hanoi(int n, char from, char work, char to){
  
  if(n > 0){
    Hanoi(n-1, from, to, work);
    printf("%d -> %d\n", from, to);
    Hanoi(n-1, work, from, to);
  }
  
  return;
  
}
