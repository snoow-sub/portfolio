 /*パッケージ名*/

/**
 * Created by YUUKI on 2016/10/02.
 */

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Camera;
import android.hardware.Camera.PictureCallback;
import android.hardware.Camera.Size;
import android.os.Environment;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;

public class CameraView extends SurfaceView
implements SurfaceHolder.Callback, PictureCallback {
    private Camera mCamera = null;
    private static final String SDCARD_FOLDER = /*画像保存場所*/;
    //private TextView txtView = (TextView)findViewById(R.id.txtView); //デバイスの画面表示
    //private String outtxt = "";
    public int Score;
    public CameraView(Context context) {
        super(context);
        // TODO Auto-generated constructor stub
        SurfaceHolder holder = getHolder();
        holder.addCallback(this);
        // 保存用フォルダ作成
        File dirs = new File(SDCARD_FOLDER);
        if(!dirs.exists()) {
            dirs.mkdir();
        }
    }

    @Override
    public void onPictureTaken(byte[] data, Camera camera) {
        // TODO Auto-generated method stub
        SimpleDateFormat date = new SimpleDateFormat("yyyyMMdd");
        String datName = "sample" + ".jpg";
        try {
            // データ保存
            savePhotoData(datName, data);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            if(mCamera != null) {
                mCamera.release();
                mCamera = null;
            }
        }
        //画像処理開始
        //画像の取得
        File file = Environment.getExternalStorageDirectory();
        Bitmap bmp = BitmapFactory.decodeFile(file.toString() + "/CameraSample/sample.jpg");

        int count = 0;
        int width = bmp.getWidth(); //幅
        int height = bmp.getHeight(); //縦
        int size = width * height;
        int px[] = new int[size];
        //bmp.getPixels(px, 0, width, 0, 0, width, height);
        long check[] = new long[4]; // 0:alpha, 1:red, 2:green, 3:blue
        for(int x = 0; x < 4; x++){
            check[x] = 0;
        }
        int pxcel = 7;
        for(int y = ((height / 2) - pxcel); y < ((height / 2) + pxcel); y++) {
            for (int x = ((width / 2) - pxcel); x < ((width / 2) + pxcel); x++) {
                px[count] = bmp.getPixel(x, y);
                check[0] += (px[count] & 0xFF000000) >> 24;
                check[1] += (px[count] & 0x00FF0000) >> 16;
                check[2] += (px[count] & 0x0000FF00) >> 8;
                check[3] += (px[count] & 0x000000FF);
                count++;
            }
        }
        int sell = (pxcel + pxcel) * (pxcel + pxcel);
        System.out.println("red : " + check[1] / sell);
        System.out.println("green : " + check[2] / sell);
        System.out.println("blue : " + check[3] / sell);
        if((check[1] / sell) > 170 && ((check[1] / sell) / 2) > (check[2] / sell) && ((check[1] / sell) / 2) > (check[3] / sell)){
            Score++;
        }
        //outtxt = String.valueOf(Score);
        //txtView.setText(outtxt);
        System.out.println("SCORE : " + Score);
        check[0] = 0;
        check[1] = 0;
        check[2] = 0;
        check[3] = 0;

        // プレビュー再開
        mCamera.startPreview();
    }

    // 画像データのセーブ
    private void savePhotoData(String datName, byte[] data) throws Exception {
        // TODO Auto-generated method stub
        FileOutputStream outStream = null;

        try {
            outStream = new FileOutputStream(SDCARD_FOLDER + datName);
            outStream.write(data);
            outStream.close();
        } catch (Exception e) {
            if(outStream != null) {
                outStream.close();
            }
            throw e;
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        // TODO Auto-generated method stub
        if(event.getAction() == MotionEvent.ACTION_DOWN) {
            // シャッターを切る
            mCamera.takePicture(null, null, this);
        }
        return true;
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        // TODO Auto-generated method stub
        mCamera = Camera.open();
        try {
            mCamera.setPreviewDisplay(holder);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        // TODO Auto-generated method stub
        mCamera.stopPreview();
        Camera.Parameters params = mCamera.getParameters();
        List<Size> previewSizes = params.getSupportedPreviewSizes();
        Size size = previewSizes.get(0);
        params.setPreviewSize(size.width, size.height);
        mCamera.setParameters(params);
        // プレビュー開始
        mCamera.startPreview();
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        // TODO Auto-generated method stub
        mCamera.stopPreview();
        mCamera.release();
        mCamera = null;
    }
}