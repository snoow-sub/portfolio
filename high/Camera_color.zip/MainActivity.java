/* パッケージ名 */

import android.app.Activity;
import android.hardware.Camera;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.SurfaceView;
import android.widget.Toast;

public class MainActivity extends Activity {
    // カメラインスタンス
    private Camera Camera = null;
    private SurfaceView Surface;
    // カメラプレビュークラス
    private CameraView preview = null;
    //音用
    private MediaPlayer m_mediaPlayer1;
    private MediaPlayer m_mediaPlayer2;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_main);
        // 音声ファイルの準備
        m_mediaPlayer1 = MediaPlayer.create(this, R.raw.nc70305);
        m_mediaPlayer2 = MediaPlayer.create(this, R.raw.nc40282);
        // SurfaceView
        Surface = (SurfaceView)findViewById(R.id.surfaceView);
        preview = new CameraView(this,Camera,Surface);
    }
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch(event.getAction()) {
            // 指が押されたら
            case MotionEvent.ACTION_DOWN :
                Toast.makeText(this, "Now Loading...", Toast.LENGTH_SHORT).show();
                // 音再生
                preview.onTouchEvent(event);
                m_mediaPlayer1.start();
                m_mediaPlayer2.start();
                break;
            default:
                break;

        }
        return super.onTouchEvent(event);
    }
}