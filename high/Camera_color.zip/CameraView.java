/* パッケージ名 */

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Camera;
import android.hardware.Camera.PictureCallback;
import android.hardware.Camera.Size;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Environment;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

public class CameraView extends SurfaceView
        implements SurfaceHolder.Callback, PictureCallback {
    private Camera mCamera = null;
    private SurfaceView surface = null;
    public SurfaceHolder holder;
    //  ログ表示用
    private static final String LOG = "CameraView";
    //シャッター連続アプリ落ち防止フラグ
    // true 押せる　false 押せない
    public boolean Shutter = true;
    private static final String SDCARD_FOLDER = /* 画像保存場所 */;
    public int Score;
    public boolean flag = false;
    public CameraView(Context context, Camera Camera, SurfaceView Surface) {
        super(context);
        // TODO Auto-generated constructor stub
        //MainActivity から持ってきたCamera Surfaceを代入
        mCamera = Camera;
        surface = Surface;
        holder = surface.getHolder();
        holder.addCallback(this);
        holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
        // 保存用フォルダ作成
        File dirs = new File(SDCARD_FOLDER);
        if(!dirs.exists()) {
            dirs.mkdir();
        }
    }

    @Override
    public void onPictureTaken(byte[] data, Camera camera) {
        Log.d(LOG, "onPictureTaken");
        // TODO Auto-generated method stub
        String datName = "sample" + ".jpg";
        try {
            // データ保存
            savePhotoData(datName, data);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            if (mCamera != null) {
                mCamera.release();
                mCamera = null;
            }
        }
        //画像処理開始
        //画像の取得
        File file = Environment.getExternalStorageDirectory();
        Bitmap bmp = BitmapFactory.decodeFile(file.toString() + /* 画像の保存場所の画像URL */);

        int count = 0;
        int px_num = 1;
        int sell = (px_num + px_num) * (px_num + px_num);
        int px[] = new int[sell + 1];
        long check[] = new long[4]; // 1:red, 2:green, 3:blue
        int width = bmp.getWidth(); //幅
        int height = bmp.getHeight(); //縦
        check[1] = check[2] = check[3] = 0;
        for (int y = ((height / 2) - px_num); y < ((height / 2) + px_num); y++) {
            for (int x = ((width / 2) - px_num); x < ((width / 2) + px_num); x++) {
                px[count] = bmp.getPixel(x, y);
                check[1] += (px[count] & 0x00FF0000) >> 16;
                check[2] += (px[count] & 0x0000FF00) >> 8;
                check[3] += (px[count] & 0x000000FF);
                count++;
            }
        }

        int ave_red = (int) check[1] / sell;
        int ave_blue = (int) check[2] / sell;
        int ave_green = (int) check[3] / sell;

        //Toast.makeText(getContext(), "RED : " + Long.toString(ave_red) + "\n" + "GREEN : " + Long.toString(ave_green) + "\n" + "BLUE : " + Long.toString(ave_blue), Toast.LENGTH_SHORT).show();
        System.out.println("RED : " + ave_red + "GREEN : " + ave_green + "BLUE : " + ave_blue);
        if(ave_red > 222 && ave_blue < 50 && (ave_green > 65 && ave_green <= 111)) {
            flag = true; //柿色（橙色）
        }else if(ave_red > 222 && (ave_red / 10) >= ave_green && (ave_red / 10) > ave_blue){
            flag = true; //赤色
        }else if(ave_red > 222 && ave_green > 222 && (((ave_red / 10) + (ave_green / 10)) / 2) > ave_blue){
            flag = true; //黄色
        }else if(((ave_red > 170) && (ave_red < 222)) && ((ave_blue > 180) && (ave_blue < 222)) && (((ave_red / 10) + (ave_blue / 10)) / 2) > ave_green){
            flag = true; //紫色
        }else if(ave_red > 222 && ave_blue > 222 && (((ave_red / 10) + (ave_blue)) / 2) > ave_green){
            flag = true; //桃色
        }else if(ave_blue > 222 && (ave_blue / 10) > ave_red && (ave_blue / 10) > ave_green){
            flag = true; //青色
        }else if(((ave_green > 105) && (ave_green < 151)) && (ave_green / 5) > ave_red && (ave_green / 5) > ave_blue){
            flag = true; //緑
        }else if(ave_green > 222 && (ave_green / 10) > ave_red && (ave_green / 10) > ave_blue){
            flag = true; //黄緑
        }else{
            flag = false;
        }
        if(flag){
            Toast.makeText(getContext(), "Hit!", Toast.LENGTH_SHORT).show();
            flag = false;
        }
        // プレビュー再開
        mCamera.startPreview();
    }

    // 画像データのセーブ
    private void savePhotoData(String datName, byte[] data) throws Exception {
        Log.d(LOG, "savePhotoData");
        // TODO Auto-generated method stub
        FileOutputStream outStream = null;

        try {
            outStream = new FileOutputStream(SDCARD_FOLDER + datName);
            outStream.write(data);
            outStream.close();
        } catch (Exception e) {
            if(outStream != null) {
                outStream.close();
            }
            throw e;
        }

        // 一連の流れが終わったらシャッター許可
        if(Shutter == false) {
            Shutter = true;
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        MediaPlayer m_mediaPlayer3;
        Log.d(LOG, "onTouchEvent");
        // TODO Auto-generated method stub
        // シャッターが許可されているか　連打落ち処理
        if ((event.getAction() == MotionEvent.ACTION_DOWN) && (Shutter == true)) {
            // シャッターを切る
            mCamera.takePicture(null, null, this);
        }else{
            m_mediaPlayer3 = MediaPlayer.create(getContext(), R.raw.nc63167);
            m_mediaPlayer3.start();
        }
        // 押せなくする
        Shutter = false;
        return true;
    }
    // シャッター音　
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR1)
    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        Log.d(LOG, "surfaceCreated");
        // TODO Auto-generated method stub
        mCamera = Camera.open();
        try {
            mCamera.setPreviewDisplay(holder);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        Log.d(LOG, "surfaceChanged");
        // TODO Auto-generated method stub
        mCamera.stopPreview();
        Camera.Parameters params = mCamera.getParameters();
        List<Size> previewSizes = params.getSupportedPreviewSizes();
        Size size = previewSizes.get(0);
        params.setPreviewSize(size.width, size.height);
        mCamera.setParameters(params);
        // プレビュー開始
        mCamera.startPreview();
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        Log.d(LOG, "surfaceDestroyed");
        // TODO Auto-generated method stub
        mCamera.stopPreview();
        mCamera.release();
        mCamera = null;
    }
}

